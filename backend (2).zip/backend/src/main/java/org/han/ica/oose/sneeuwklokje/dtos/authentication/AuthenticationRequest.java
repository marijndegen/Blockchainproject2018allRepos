package org.han.ica.oose.sneeuwklokje.dtos.authentication;

import lombok.Getter;
import lombok.Setter;

public class AuthenticationRequest {
    @Getter
    @Setter
    private String token;
}
