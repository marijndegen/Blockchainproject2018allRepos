package org.han.ica.oose.sneeuwklokje.database.election;

import org.han.ica.oose.sneeuwklokje.database.DatabaseConnector;

import javax.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ElectionDaoImpl implements ElectionDao {

    @Inject
    DatabaseConnector databaseConnector;

    /**
     * Returns the id of an election based on a user token.
     * @param token
     * @return
     */
    @SuppressWarnings("Duplicates")
    @Override
    public int getIdOfElectionBasedOnToken(String token) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT E.id, ET.token as token FROM Election E INNER JOIN ElectionToken ET ON E.id = ET.electionID WHERE ET.token = ?";

        try {
            con = databaseConnector.createConnection();
            ps = con.prepareStatement(query);

            ps.setString(1, token);
            rs = ps.executeQuery();
            rs.next();
            int id = rs.getInt("id");
            String databaseToken = rs.getString("token");
            if (token.equals(databaseToken)) {
                rs.close();
                ps.close();
                con.close();
                return id;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
