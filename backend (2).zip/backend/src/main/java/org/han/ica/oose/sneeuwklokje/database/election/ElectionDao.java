package org.han.ica.oose.sneeuwklokje.database.election;

import java.sql.SQLException;

public interface ElectionDao {

    int getIdOfElectionBasedOnToken(String token) throws SQLException;
}
