package org.han.ica.oose.sneeuwklokje.dtos.election;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ElectionResponse {

}
