package org.han.ica.oose.sneeuwklokje.database.voter;

import org.han.ica.oose.sneeuwklokje.database.DatabaseConnector;

import javax.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VoterDaoImpl implements VoterDao {

    @Inject
    DatabaseConnector databaseConnector;

    /**
     * Verifies the token of a user. Returns wether the users has a correct token.
     * @param token the token to check.
     * @return
     */
    @Override
    public boolean checkAuthenticationToken(String token) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT token FROM TokenVoter WHERE token = ?";

        try {
            con = databaseConnector.createConnection();
            ps = con.prepareStatement(query);

            ps.setString(1, token);
            rs = ps.executeQuery();
            rs.next();

            if (token.equals(rs.getString("token"))) {
                rs.close();
                ps.close();
                con.close();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes the token of a user, this method is called when the voter voted, so his vote stays anonymous.
     * @param token the token to delete.
     */
    @Override
    public void deleteTokenAfterVote(String token) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "DELETE FROM TokenVoter WHERE token = ?";

        try {
            con = databaseConnector.createConnection();
            ps = con.prepareStatement(query);

            ps.setString(1, token);
            rs = ps.executeQuery();

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
