package org.han.ica.oose.sneeuwklokje.database.authentication;

import org.han.ica.oose.sneeuwklokje.database.DatabaseConnector;

import javax.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthenticationDaoImpl implements AuthenticationDao {

}
