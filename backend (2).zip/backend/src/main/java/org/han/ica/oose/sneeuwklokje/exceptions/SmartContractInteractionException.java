package org.han.ica.oose.sneeuwklokje.exceptions;

public class SmartContractInteractionException extends Exception {
    public SmartContractInteractionException() {
    }

    public SmartContractInteractionException(String message) {
        super(message);
    }

    public SmartContractInteractionException(String message, Throwable cause) {
        super(message, cause);
    }

    public SmartContractInteractionException(Throwable cause) {
        super(cause);
    }

    public SmartContractInteractionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
