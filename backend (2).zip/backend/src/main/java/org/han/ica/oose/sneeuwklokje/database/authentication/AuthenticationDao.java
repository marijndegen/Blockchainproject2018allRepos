package org.han.ica.oose.sneeuwklokje.database.authentication;

import java.sql.SQLException;

public interface AuthenticationDao {

}
