package org.han.ica.oose.sneeuwklokje.controllers;

import org.han.ica.oose.sneeuwklokje.dtos.voter.VoterRequest;
import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;
import org.han.ica.oose.sneeuwklokje.services.election.ElectionService;
import org.han.ica.oose.sneeuwklokje.services.voter.VoterService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("vote")
public class VoterRestController {

    @Inject
    private VoterService voterService;

    @Inject
    private ElectionService electionService;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response vote(VoterRequest request) {
        String token = request.getToken();
        boolean tokenIsValid = voterService.doAuthenticationToken(token);
        if(tokenIsValid){
            int id = request.getId();
            int electionId = electionService.getElectionIdBasedOnToken(token);

            try {
                String smartContractAddress = electionService.getSmartContractAddress(electionId);
                System.out.println(smartContractAddress);
                voterService.pushVoteToBlockchain(token, id, smartContractAddress);
                return Response.ok().build();
            } catch (SmartContractInteractionException e) {
                e.printStackTrace();
                return Response.status(500).build();
            }
        }
        return Response.status(400).build();
    }
}

