package org.han.ica.oose.sneeuwklokje.controllers;

import org.han.ica.oose.sneeuwklokje.dtos.authentication.AuthenticationRequest;
import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;
import org.han.ica.oose.sneeuwklokje.services.election.ElectionService;
import org.han.ica.oose.sneeuwklokje.services.voter.VoterService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("authentication")
public class AuthenticationRestController {

    @Inject
    private VoterService voterService;

    @Inject
    private ElectionService electionService;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticate(AuthenticationRequest request) {
        String token = request.getToken();
        boolean tokenIsValid = voterService.doAuthenticationToken(token);
        int electionId = electionService.getElectionIdBasedOnToken(token);
        if (tokenIsValid && electionId != 0) {
            String smartContractAddress = electionService.getSmartContractAddress(electionId);
            try {
                return Response.ok().entity(electionService.createBallotResponse(electionId, smartContractAddress)).build();
            } catch (SmartContractInteractionException e) {
                e.printStackTrace();
                return Response.status(500).build();
            }
        } else {
            return Response.status(403).build();
        }
    }

}
