package org.han.ica.oose.sneeuwklokje.dtos.election;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberRequest {
    private String initials;
    private String firstname;
    private String lastname;
    private String gender;
    private String location;
    private int position;
}
