package org.han.ica.oose.sneeuwklokje.dtos.voter;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VoterRequest {
    private int id;
    private String token;
}
