package org.han.ica.oose.sneeuwklokje.services;

import org.han.ica.oose.sneeuwklokje.database.election.ElectionDao;
import org.han.ica.oose.sneeuwklokje.services.election.ElectionServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.SQLException;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ElectionServiceImplTest {
    @Mock
    private ElectionDao electionDao;

    @InjectMocks
    private ElectionServiceImpl electionService;

    @Test
    public void testIfCheckIdOfElectionOfVoterReturnsOneIfTokenIsInDatabase() throws SQLException {
        when(electionDao.checkIdOfElectionOfVoter("")).thenReturn(1);
        int election = electionService.getElectionIdBasedOnToken("");
        Assert.assertEquals(1, election);
    }

    @Test
    public void testIfCheckIdOfElectionOfVoterReturnsZeroIfTokenIsNotInDatabase() throws SQLException {
        when(electionDao.checkIdOfElectionOfVoter("")).thenReturn(0);
        int election = electionService.getElectionIdBasedOnToken("");
        Assert.assertEquals(0, election);
    }
}
