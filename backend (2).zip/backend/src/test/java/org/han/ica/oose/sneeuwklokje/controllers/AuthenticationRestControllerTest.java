package org.han.ica.oose.sneeuwklokje.controllers;

import org.han.ica.oose.sneeuwklokje.dtos.authentication.AuthenticationRequest;
import org.han.ica.oose.sneeuwklokje.dtos.election.ElectionResponse;
import org.han.ica.oose.sneeuwklokje.services.authentication.AuthenticationService;
import org.han.ica.oose.sneeuwklokje.services.election.ElectionService;
import org.han.ica.oose.sneeuwklokje.services.voter.VoterService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.core.Response;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthenticationRestControllerTest {

    @Mock
    private VoterService voterService;

    @Mock
    private ElectionService electionService;

    @Mock
    private AuthenticationRequest rq;
    @Mock
    private ElectionResponse rs;

    @InjectMocks
    private AuthenticationRestController authenticationRestController;

    @Before
    public void setup() {
        rq = new AuthenticationRequest();
        rs = new ElectionResponse();
    }

    @Test
    public void testIfEmptyRequestReturnsStatus403() {
        when(voterService.doAuthenticationToken("")).thenReturn(false);
        when(electionService.getElectionIdBasedOnToken("")).thenReturn(1);
        Response resp = authenticationRestController.authenticate(rq);
        Assert.assertEquals(403, resp.getStatus());
    }

    @Test
    public void testIfAuthenticateRequestReturnsStatus200() {
        rq.setToken("1234-1234-1234");
        when(voterService.doAuthenticationToken("1234-1234-1234")).thenReturn(true);
        when(electionService.getElectionIdBasedOnToken("1234-1234-1234")).thenReturn(1);
        Response resp = authenticationRestController.authenticate(rq);
        Assert.assertEquals(200, resp.getStatus());
    }
}
