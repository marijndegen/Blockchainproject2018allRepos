package org.han.ica.oose.sneeuwklokje.database;

import org.han.ica.oose.sneeuwklokje.database.authentication.AuthenticationDaoImpl;
import org.junit.Assert;
import org.junit.Test;

public class AuthenticationDaoImplTest {

/*    AuthenticationDaoImpl authenticationDaoImpl = new AuthenticationDaoImpl();

    @Test
    public void testIfDatabaseConnectionIsEstablished() {
        Assert.assertTrue(authenticationDaoImpl.checkAuthenticationToken("1234-1234-1234"));
    }*/
}
