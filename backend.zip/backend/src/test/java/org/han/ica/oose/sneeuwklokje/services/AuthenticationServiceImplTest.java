package org.han.ica.oose.sneeuwklokje.services;

import org.han.ica.oose.sneeuwklokje.database.authentication.AuthenticationDao;
import org.han.ica.oose.sneeuwklokje.database.voter.VoterDao;
import org.han.ica.oose.sneeuwklokje.services.authentication.AuthenticationServiceImpl;
import org.han.ica.oose.sneeuwklokje.services.voter.VoterService;
import org.han.ica.oose.sneeuwklokje.services.voter.VoterServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.SQLException;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthenticationServiceImplTest {

    @Mock
    private VoterDao voterDao;

    @InjectMocks
    private VoterServiceImpl voterService;

    @Test
    public void testIfDoAuthenticationTokenTrueIs() throws SQLException {
        when(voterDao.checkAuthenticationToken("")).thenReturn(true);
        boolean authentication = voterService.doAuthenticationToken("");
        Assert.assertEquals(true, authentication);
    }

    @Test
    public void testIfDoAuthenticationTokenFalseIs() throws SQLException {
        when(voterDao.checkAuthenticationToken(anyString())).thenReturn(false);
        boolean authentication = voterService.doAuthenticationToken("");
        Assert.assertEquals(false, authentication);
    }
}
