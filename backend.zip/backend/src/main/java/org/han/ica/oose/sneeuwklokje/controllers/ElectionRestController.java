package org.han.ica.oose.sneeuwklokje.controllers;

import org.han.ica.oose.sneeuwklokje.contracts.ContractConnector;
import org.han.ica.oose.sneeuwklokje.contracts.Election;
import org.han.ica.oose.sneeuwklokje.exceptions.InvalidCredentialsException;
import org.han.ica.oose.sneeuwklokje.exceptions.NoServiceNodeException;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.tx.Contract;
import org.web3j.tx.ManagedTransaction;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import java.io.IOException;

@Path("election")
public class ElectionRestController {

    @Inject
    private ContractConnector contractConnector;

    @Path("deploy")
    @POST
    public Response deployContract() {
        //fixme make a service layer for the election.

        //Deploy
        Election electionContract;
        try {
            Credentials credentials = contractConnector.getWalletCredentials();
            Web3j web3j = contractConnector.getWeb3jservice();
            System.out.println("Credentials loaded");
            electionContract = Election.deploy(web3j, credentials, ManagedTransaction.GAS_PRICE, Contract.GAS_LIMIT).send();
/*            electionContract.setElectionName("testelection").send();
            electionContract.addParty("Marijnscoolepartij").send();*/
            System.out.println("Deploying contract");
            String contractAddress = electionContract.getContractAddress();
            System.out.println("Smart contract deployed to address " + contractAddress);
            System.out.println("View contract at https://rinkeby.etherscan.io/address/" + contractAddress);
            return Response.ok().build();
            //fixme er moet nog een naam en attributen worden meegegeven aan het smart contract. De hardcoded waarden moeten nog worden vervangen.
        } catch (IOException | NoServiceNodeException | InvalidCredentialsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Response.status(500).build();
    }

}
