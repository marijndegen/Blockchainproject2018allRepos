package org.han.ica.oose.sneeuwklokje.dtos.voter;

public class VoterResponse {
    // Not used for this Sprint
}
