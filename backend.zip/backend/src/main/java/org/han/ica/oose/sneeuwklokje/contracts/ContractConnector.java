package org.han.ica.oose.sneeuwklokje.contracts;

import org.han.ica.oose.sneeuwklokje.exceptions.InvalidCredentialsException;
import org.han.ica.oose.sneeuwklokje.exceptions.NoServiceNodeException;
import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;
import org.web3j.crypto.CipherException;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.WalletUtils;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.ManagedTransaction;
import org.web3j.utils.Async;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Properties;

public class ContractConnector implements SenderWallet{

    private Properties properties;

    public ContractConnector() throws InvalidCredentialsException {
        properties = new Properties();
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            throw new InvalidCredentialsException("Something went wrong while trying to load wallet file.", e);
        }
    }

    public Credentials getWalletCredentials() throws InvalidCredentialsException {
        String absolutepathtowallet = properties.getProperty("absolutepathtowallet");
        String walletpassword = properties.getProperty("walletpassword");
        try {
            Credentials credentials = WalletUtils.loadCredentials(walletpassword, absolutepathtowallet);
            return credentials;
        } catch (CipherException e) {
            throw new InvalidCredentialsException("The wallet file you provided is either not valid, or the password provided is not correct", e);
        } catch (IOException e) {
            throw new InvalidCredentialsException("The wallet file you provided is either not valid, or the password provided is not correct", e);
        }
    }

    public Web3j getWeb3jservice() throws NoServiceNodeException {
        String primarynode = properties.getProperty("primarynode");
        String secondarynode = properties.getProperty("secondarynode");
        int pollinginterval = Integer.parseInt(properties.getProperty("pollinginterval"));
        Web3j web3j;
        try{
            web3j = Web3j.build(new HttpService(primarynode) ,pollinginterval, Async.defaultExecutorService());
        }catch(Exception p){
            try{
                web3j = Web3j.build(new HttpService(secondarynode),pollinginterval, Async.defaultExecutorService());
            }catch(Exception s){
                throw new NoServiceNodeException("Couldn't connect to the primary and secondary node. Are you sure both nodes are up and running? Are you connected to the internet?", p);
            }
        }
        return web3j;
    }

    public Election getElection(String electionAddress, BigInteger gasPrice) throws SmartContractInteractionException {
        Credentials credentials;
        Web3j web3j;
        try {
            credentials = this.getWalletCredentials();
            web3j = this.getWeb3jservice();
        } catch (InvalidCredentialsException e) {
            throw new SmartContractInteractionException("An error occurred during the voting process. Check the wallet credentials");
        } catch (NoServiceNodeException e) {
            throw new SmartContractInteractionException("An error occurred during the connection process. " + e.getMessage());
        }

        Election election = Election.load(electionAddress, web3j, credentials, BigInteger.valueOf(4300000), BigInteger.valueOf(4300000));
        election.setGasPrice(gasPrice);
        return election;
    }

    public Election getElection(String electionAddress) throws SmartContractInteractionException{
        return this.getElection(electionAddress, ManagedTransaction.GAS_PRICE);
    }

    @Deprecated
    public String testSmartContract(){
        return properties.getProperty("testsmartcontract");
    }
}
