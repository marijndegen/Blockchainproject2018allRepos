package org.han.ica.oose.sneeuwklokje.services.authentication;

import org.han.ica.oose.sneeuwklokje.database.authentication.AuthenticationDao;

import javax.inject.Inject;
import java.sql.SQLException;

public class AuthenticationServiceImpl implements AuthenticationService {

/*    @Inject
    private AuthenticationDao authenticationDao;*/
}
