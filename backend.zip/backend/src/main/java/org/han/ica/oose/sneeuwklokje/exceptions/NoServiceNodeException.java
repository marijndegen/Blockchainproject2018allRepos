package org.han.ica.oose.sneeuwklokje.exceptions;

public class NoServiceNodeException extends Exception {
    public NoServiceNodeException() {
    }

    public NoServiceNodeException(String message) {
        super(message);
    }

    public NoServiceNodeException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoServiceNodeException(Throwable cause) {
        super(cause);
    }

    public NoServiceNodeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
