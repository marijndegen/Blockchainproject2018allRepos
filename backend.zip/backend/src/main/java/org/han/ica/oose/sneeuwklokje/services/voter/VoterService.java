package org.han.ica.oose.sneeuwklokje.services.voter;

import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;

public interface VoterService {
    boolean doAuthenticationToken(String token);

    void pushVoteToBlockchain(String token, int id, String smartContractAddress) throws SmartContractInteractionException;

    void deleteTokenFromDatabaseAfterVote(String token);
}
