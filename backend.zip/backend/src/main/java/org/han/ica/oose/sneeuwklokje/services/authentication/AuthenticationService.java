package org.han.ica.oose.sneeuwklokje.services.authentication;

public interface AuthenticationService {
}
