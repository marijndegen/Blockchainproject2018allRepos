package org.han.ica.oose.sneeuwklokje.services.voter;

import org.han.ica.oose.sneeuwklokje.contracts.ContractConnector;
import org.han.ica.oose.sneeuwklokje.contracts.Election;
import org.han.ica.oose.sneeuwklokje.database.voter.VoterDao;
import org.han.ica.oose.sneeuwklokje.exceptions.InvalidCredentialsException;
import org.han.ica.oose.sneeuwklokje.exceptions.NoServiceNodeException;
import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;

import javax.inject.Inject;
import java.math.BigInteger;
import java.sql.SQLException;

public class VoterServiceImpl implements VoterService {

    @Inject
    private VoterDao voterDao;

    @Inject
    private ContractConnector contractConnector;

    @SuppressWarnings("Duplicates")
    @Override
    public void pushVoteToBlockchain(String token, int id, String smartContractAddress) throws SmartContractInteractionException {
        Election electionContract = contractConnector.getElection(smartContractAddress);

        // Save the vote to the blockchain by incrementing the voteCount of the chosen party member
        try {
            System.out.println(electionContract.getGasPrice());
            TransactionReceipt receipt  = electionContract.vote(BigInteger.valueOf(id), token).send();
            System.out.println(receipt);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Remove the now used token from the database to prevent people from voting twice with the same token.
        //deleteTokenFromDatabaseAfterVote(token);
    }

    @Override
    // Remove the now used token from the database to prevent people from voting twice with the same token.
    public void deleteTokenFromDatabaseAfterVote(String token) {
        voterDao.deleteTokenAfterVote(token);
    }

    @Override
    public boolean doAuthenticationToken(String token) {
        return voterDao.checkAuthenticationToken(token);
    }
}
