package org.han.ica.oose.sneeuwklokje.services.election;

import org.han.ica.oose.sneeuwklokje.contracts.ContractConnector;
import org.han.ica.oose.sneeuwklokje.contracts.Election;
import org.han.ica.oose.sneeuwklokje.database.election.ElectionDao;
import org.han.ica.oose.sneeuwklokje.dtos.authentication.electionform.BallotResponse;
import org.han.ica.oose.sneeuwklokje.dtos.authentication.electionform.Member;
import org.han.ica.oose.sneeuwklokje.dtos.authentication.electionform.Party;
import org.han.ica.oose.sneeuwklokje.exceptions.InvalidCredentialsException;
import org.han.ica.oose.sneeuwklokje.exceptions.NoServiceNodeException;
import org.han.ica.oose.sneeuwklokje.exceptions.SmartContractInteractionException;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.tuples.generated.Tuple3;
import org.web3j.tuples.generated.Tuple8;

import javax.inject.Inject;
import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ElectionServiceImpl implements ElectionService {
    @Inject
    private ElectionDao electionDao;

    @Inject
    private ContractConnector contractConnector;

    @Override
    public int getElectionIdBasedOnToken(String token){
        try {
            return electionDao.checkIdOfElectionOfVoter(token);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; //Fixme change when the database is correct.
    }

    @Override
    public String getSmartContractAddress(int electionId) {
        return contractConnector.testSmartContract(); //Fixme change when the database is correct.
/*        try {
            return electionDao.getSmartContractAddressFromDatabase(int electionId);
        } catch (SQLException e) {
            e.printStackTrace();
        }*/
    }

    @Override
    public BallotResponse createBallotResponse(int electionId, String smartContractAddress) throws SmartContractInteractionException {
        Election electionContract = contractConnector.getElection(smartContractAddress);
        BigInteger numberOfParties;
        BigInteger numberOfMembers;

        String electionName = null;

        String beginDate;
        String endDate;

        List<Party> electionParties = new ArrayList<>();

        try {
            //Get the number of parties and the number or members
            numberOfParties = electionContract.getNumberOfParties().send();
            numberOfMembers = electionContract.membersCount().send();

            //Get the name of the Election
            electionName = electionContract.name().send();

            BigInteger electionStartDate = electionContract.startDate().send();
            BigInteger electionEndDate = electionContract.endDate().send();

            Date startDate = new java.util.Date(electionStartDate.longValue() * 1000L);
            Date stopDate = new java.util.Date(electionEndDate.longValue() * 1000L);

            SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT+2"));

            beginDate = sdf.format(startDate);
            endDate = sdf.format(stopDate);
            System.out.println(beginDate);
            System.out.println(endDate);

            //Get all parties
            for(int i = 0; i < numberOfParties.intValue(); i++){
                Tuple3<BigInteger, String, BigInteger> party = electionContract.parties(BigInteger.valueOf(i)).send();
                System.out.println(party);
                Party partyDto = new Party();
                partyDto.setId(i);
                partyDto.setName(party.getValue2());
                electionParties.add(i, partyDto);
            }

            //Get all members and add them to parties.
            for(int i = 0; i <numberOfMembers.intValue(); i++){
                Tuple8<BigInteger, BigInteger, String, String, String, String, String, BigInteger> member = electionContract.members(BigInteger.valueOf(i)).send();
                System.out.println(member);
                int id = member.getValue1().intValue();
                int position = member.getValue2().intValue();
                String lastName = member.getValue3();
                String initials = member.getValue4();
                String firstName = member.getValue5();
                String gender = member.getValue6();
                String location = member.getValue7();
                int partyId = member.getValue8().intValue();
                electionParties.get(partyId).addMember(new Member(id, position, lastName, initials, firstName, gender, location));
            }

        } catch (Exception e) {
            e.printStackTrace();
            //fixme look if this is fixed now.
            throw new SmartContractInteractionException(/*"Could not fetch data from the smart contract: Election, make sure the network is running and access is configured properly."*/ e.getMessage());
        }
        return new BallotResponse(electionId, electionName, electionParties, beginDate.toString(), endDate.toString());
    }
}
