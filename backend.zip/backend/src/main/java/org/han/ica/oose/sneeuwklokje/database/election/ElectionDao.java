package org.han.ica.oose.sneeuwklokje.database.election;

import java.sql.SQLException;

public interface ElectionDao {

    int checkIdOfElectionOfVoter(String token) throws SQLException;
}
