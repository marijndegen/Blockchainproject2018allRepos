package org.han.ica.oose.sneeuwklokje.database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnector {

    private static String connectionString;
    private static String connectionUser;
    private static String connectionPassword;

    public DatabaseConnector() {
        Properties properties = new Properties();
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            Class.forName(properties.getProperty("driver"));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        connectionString = properties.getProperty("connectionString");
        connectionUser = properties.getProperty("user");
        connectionPassword = properties.getProperty("password");
    }

    public Connection createConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(connectionString, connectionUser, connectionPassword);
        } catch (SQLException e) {
            System.out.println("Error connecting to a database: " + e);
        }
        return conn;
    }
}
